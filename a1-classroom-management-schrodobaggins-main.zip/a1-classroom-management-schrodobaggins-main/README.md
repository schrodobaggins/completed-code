# CSC 413 Assignment 1 README

Name: Michael Schroeder
Email: mschroeder@mail.sfsu.edu
